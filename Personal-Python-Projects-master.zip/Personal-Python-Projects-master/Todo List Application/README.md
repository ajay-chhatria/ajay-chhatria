## Todo List Application

**Dscription:-**

The To do List In Python is a simple project developed using Python. This project is a GUI application which stores the list of works to do from the users input. This project is an interesting and simple project. The project is not completely functional. You can add, edit many more features in this project

**About the system:-**

This to do list application is designed to create your to do list with the required time and you can also get the notification/remainder when you have to to your task. Here, the module used is Tkinter()-It is a standard Python interface to the Tk GUI toolkit shipped with Python. Python with tkinter outputs the fastest and easiest way to create the GUI applications. Creating a GUI using tkinter is an easy task. Also, the design of this system is pretty simple so that the user won’t get any difficulties while working on it.

**How To Run The Project?**

To run this project, you must have installed **[Python](https://www.python.org/downloads/)** on your PC. After downloading it, follow the steps below:

**Step1:** Clone this repository in your Local machine.

**Step 2:** Go inside the project folder, open cmd then type main.py and enter to start the system.

**OR**

**Step 2:** Simply, double click the main.py file and you are ready to go.
